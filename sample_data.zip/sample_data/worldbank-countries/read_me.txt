World Bank Official Boundaries
Description: Country borders and boundaries provided by World Bank at a 10m resolution.

Downloaded from: https://datacatalog.worldbank.org/search/dataset/0038272/World-Bank-Official-Boundaries
Geographic Coordinate System: WGS 1984 EPSG: 4326
Date: 10/01/2024
Resolution: 10m