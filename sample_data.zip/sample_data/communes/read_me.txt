Commune administrative boundaries taken from below and reprojected into WGS84 for NUBB workshop.

Basic map of Cambodia (2014)

These datasets contain three different types of administrative boundary levels: provincial, district and commune which were contributed by Office for the Coordination of Humanitarian Affairs (OCHA) to Humanitarian Data Exchange (HDX). The datasets were obtained from the Department of Geography of Ministry of Land Management, Urban Planning and Construction (MLMUPC) in 2008 and then unofficially updated in 2014 by referring to Sub-decrees on administrative modifications. Most Recent Changes: New province added (Tbong Khmum), with underlying districts and communes.

Responsible party: 
OCHA in Asia and the Pacific Email: unocha@un.org Website: http://www.unocha.org/

Metadata last updated on 2016-09-21. For inquiries contact: Open Development Cambodia. Address: #43 St. 208, Phnom Penh, Cambodia. Email: contact@opendevcam.net Website: http://www.opendevcam.net

GCS: WGS84, Zone: 48 North
Projection: UTM (Reprojected to WGS84)


Retrieved: 24/11/2023
Retrieved from: https://data.opendevelopmentcambodia.net/en/dataset/administrative-boundaries-of-cambodia-2014
